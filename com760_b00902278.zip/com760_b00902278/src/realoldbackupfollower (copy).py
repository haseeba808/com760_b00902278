#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist, PoseStamped
from math import atan2, sqrt

leader_pose = PoseStamped()

def leader_callback(data):
    global leader_pose
    leader_pose = data

def distance(p1, p2):
    return sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2)

def angle(p1, p2):
    return atan2(p2.y - p1.y, p2.x - p1.x)

def main():
    rospy.init_node('follower')

    follower_pub = rospy.Publisher('/turtle2/cmd_vel', Twist, queue_size=10)

    leader_sub = rospy.Subscriber('/turtle1/pose', PoseStamped, leader_callback)

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        # Calculate the distance and angle to the leader turtle
        d = distance(leader_pose.pose.position, rospy.get_param('~initial_pose').position)
        phi = angle(rospy.get_param('~initial_pose'), leader_pose.pose.position) - leader_pose.pose.orientation.z

        # Maintain a distance of 2 units from the leader turtle
        cmd_vel = Twist()
        if d > 2:
            cmd_vel.linear.x = 2 * (d - 2)
        else:
            cmd_vel.linear.x = 0

        # Maintain an orientation aligned with the leader turtle
        if phi > 0:
            cmd_vel.angular.z = 2 * phi
        else:
            cmd_vel.angular.z = 0

        follower_pub.publish(cmd_vel)

        rate.sleep()
#
#if __name__ == '__main__':
#	try:
	 #  	main()
	#except rospy.ROSInterruptException:
	     # pass

