#! /usr/bin/env python 
import rospy 

rospy.init_node("Com760_Task2")
rate = rospy.Rate(2)
while not rospy.is_shutdown():
	print "Help me world!!!"
	rate.sleep()



