#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist, Pose
from turtlesim.msg import Pose as TurtlePose

class Follower:
    def __init__(self):
        self.desired_distance = 2.0
        self.linear_vel = 0.0
        self.angular_vel = 0.0
        self.pose = TurtlePose()
        self.leader_pose = TurtlePose()
        self.sub_leader_pose = rospy.Subscriber("/turtle1/pose", TurtlePose, self.leader_pose_callback)
        self.pub_cmd_vel = rospy.Publisher("/turtle2/cmd_vel", Twist, queue_size=10)
        self.sub_pose = rospy.Subscriber("/turtle2/pose", TurtlePose, self.pose_callback)

    def leader_pose_callback(self, data):
        self.leader_pose = data

    def pose_callback(self, data):
        self.pose = data
        self.move()

    def move(self):
        dx = self.leader_pose.x - self.pose.x
        dy = self.leader_pose.y - self.pose.y
        distance = (dx ** 2 + dy ** 2) ** 0.5
        angle = self.leader_pose.theta - self.pose.theta

        if angle > 3.14:
            angle -= 6.28
        elif angle < -3.14:
            angle += 6.28

        if distance > self.desired_distance:
            self.linear_vel = 2.0 * distance
            self.angular_vel = 4.0 * angle
        else:
            self.linear_vel = 0.0
            self.angular_vel = 0.0

        cmd_vel = Twist()
        cmd_vel.linear.x = self.linear_vel
        cmd_vel.angular.z = self.angular_vel
        self.pub_cmd_vel.publish(cmd_vel)

if __name__ == "__main__":
    rospy.init_node("follower")
    follower = Follower()
    rospy


